/*:
## Exercise - Type Inference and Required Values
 
 Declare a variable called `name` of type `String`, but do not give it a value. Print `name` to the console. Does the code compile? Remove any code that will not compile.
 */
var name: String
print("The code does not compile because 'name' is declared but has not been given an initial value.A variable must be initialized before it can be used.")
//:  Now assign a value to `name`, and print it to the console.
name = "Hello"
print(name)
//:  Declare a variable called `distanceTraveled` and set it to 0. Do not give it an explicit type.
var distanceTraveled: Double = 0

//:  Now assign a value of 54.3 to `distanceTraveled`. Does the code compile? Go back and set an explicit type on `distanceTraveled` so the code will compile.
distanceTraveled = 54.3
print("Swift infers the type of distanceTraveled from the initial value 0, so it becomes an Int. The value 54.3 is a Double, and Swift does not automatically convert between Int and Double")
/*:
[Previous](@previous)  |  page 9 of 10  |  [Next: App Exercise - Percent Completed](@next)
 */
