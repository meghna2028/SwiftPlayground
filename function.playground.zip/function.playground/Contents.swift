//func functionName (parameters) -> return type{}
func displayPi(){
    print("3.1415926535")
}
displayPi()

//parameter are passed when func is called
func triple(value:Int){
    let result = value * 3
    print("If you multiply \(value) by 3 , you'll get \(result).")
}
triple(value: 10)
//return value
func multiply(firstNumber: Int, secondNumber: Int) -> Int{
    let result = firstNumber * secondNumber
    return result
}
print("10 * 20 is \(multiply(firstNumber : 10,secondNumber : 20))")
//firstNumber is called argument labels
//10 is argument
//name used for readability is called external names
func sayHello(to name:String, and anotherName:String){
    print("hello \(name) and \(anotherName)")
}
sayHello(to: "A", and: "B")

//omitting label
func printData(_ num: Int){
    print("Data = \(num)")
}
printData(10)
//return keyword is optional if one line statement code
//default value assign
func add(_ firstNumber: Int , _ secondNumber: Int = 0) -> Int{
    firstNumber + secondNumber
}
print(add(10))
//put default on right hand side
//as add(,10)doesnt make sense
