import Foundation
class Event {
    var eventName: String
    var location: String
    var date: String
    var organizer: String
    init(eventName: String, location: String, date: String, organizer: String) {
        self.eventName = eventName
        self.location = location
        self.date = date
        self.organizer = organizer
    }
    func scheduleEvent() {
        print("\(eventName) has been scheduled.")
    }
    func rescheduleEvent(newDate: String) {
        date = newDate
        print("\(eventName) has been rescheduled to \(date).")
    }
    func displayInfo() {
        print("Event Name: \(eventName)")
        print("Location: \(location)")
        print("Date: \(date)")
        print("Organizer: \(organizer)")
    }
}
class Satsang: Event {
    var speakerName: String
    var bhajanList: [String]
    var duration: Int
    init(eventName: String, location: String, date: String, organizer: String,
         speakerName: String, duration: Int) {
        self.speakerName = speakerName
        self.duration = duration
        self.bhajanList = []

        super.init(eventName: eventName, location: location, date: date, organizer: organizer)
    }
    func addBhajan(_ bhajanName: String) {
        bhajanList.append(bhajanName)
    }
    func displayBhajans() {
        print("Bhajans:")
        for bhajan in bhajanList {
            print("\(bhajan)")
        }
    }
    override func displayInfo() {
        super.displayInfo()
        print("Speaker: \(speakerName)")
        print("Duration: \(duration) minutes")
    }
}
class Concert: Event {
    var performer: String
    var genre: String
    var ticketPrice: Double
    var seatsAvailable: Int
    init(eventName: String, location: String, date: String, organizer: String,
         performer: String, genre: String,
         ticketPrice: Double, seatsAvailable: Int) {
        self.performer = performer
        self.genre = genre
        self.ticketPrice = ticketPrice
        self.seatsAvailable = seatsAvailable
        super.init(eventName: eventName, location: location, date: date, organizer: organizer)
    }
    func bookTicket(count: Int) {
        if count <= seatsAvailable {
            seatsAvailable -= count
            print("\(count) ticket(s) booked.")
        } else {
            print("Not enough seats available.")
        }
    }
    func isSoldOut() -> Bool {
        return seatsAvailable == 0
    }
    override func displayInfo() {
        super.displayInfo()
        print("Performer: \(performer)")
        print("Genre: \(genre)")
        print("Ticket Price: ₹\(ticketPrice)")
        print("Seats Available: \(seatsAvailable)")
    }
}
class MeditationSession: Satsang {
    var meditationType: String
    init(eventName: String, location: String, date: String, organizer: String,
         speakerName: String, duration: Int,
         meditationType: String) {
        self.meditationType = meditationType
        super.init(eventName: eventName,
                   location: location,
                   date: date,
                   organizer: organizer,
                   speakerName: speakerName,
                   duration: duration)
    }
    override func displayInfo() {
        super.displayInfo()
        print("Meditation Type: \(meditationType)")
    }
}
class RockConcert: Concert {
    var bandName: String
    init(eventName: String, location: String, date: String, organizer: String,
         performer: String, genre: String,
         ticketPrice: Double, seatsAvailable: Int,
         bandName: String) {
        self.bandName = bandName
        super.init(eventName: eventName,
                   location: location,
                   date: date,
                   organizer: organizer,
                   performer: performer,
                   genre: genre,
                   ticketPrice: ticketPrice,
                   seatsAvailable: seatsAvailable)
    }
    override func displayInfo() {
        super.displayInfo()
        print("Band Name: \(bandName)")
    }
}
let satsang = MeditationSession(
    eventName: "Peace",
    location: "Temple Hall",
    date: "10 Aug 2026",
    organizer: "ISKCON",
    speakerName: "Swami",
    duration: 90,
    meditationType: "Guided Meditation"
)
satsang.scheduleEvent()
satsang.addBhajan("Om Jai Jagdish Hare")
satsang.addBhajan("Hare Krishna")
satsang.displayBhajans()
satsang.displayInfo()
let concert = RockConcert(
    eventName: "Rock Night",
    location: "Mumbai Arena",
    date: "20 Aug 2026",
    organizer: "Live Nation",
    performer: "Imagine Dragons",
    genre: "Rock",
    ticketPrice: 2500,
    seatsAvailable: 5,
    bandName: "Imagine Dragons"
)
concert.bookTicket(count: 2)
concert.displayInfo()
print("Sold Out: \(concert.isSoldOut())")
