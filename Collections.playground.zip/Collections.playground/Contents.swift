//2 types of collection - Array and Dictionaries
//ARRAYS
/*var arr1: [Int] = [1,2,3,4,5]
var array1 : [Any] = []
array1 = [1,2,3,4,5,"abc",true]
//only for homogeneous contain type annotation is not compulsory
if arr1.contains(5){
    print("EXISTS")
}
if array1.contains(where:{$0 is String}){
    print("Exists")
}
//$0 is checking weather 1st element is string
if array1.contains(where: {($0 as? Int) == 3}){
    print("Exists")
}

//repeating keyword
var myArray = [Int](repeating: 0, count: 10)
let count = myArray.count
if myArray.isEmpty{
    print("\(myArray)")
}
else{
    print("\(myArray)")
}

//accessing or setting a specific item
var name = ["Andre","Aileen","Anthony"]
let firstName = name[0]
print(firstName)
name[1] = "Paul"
print(name)*/
//APPENDING
/*var names = ["Andre","Aileen","Anthony"]
names.append("Aisha")
print(names)
names += ["Anisha"]
print(names)

//INSERTING
var name = ["Andre","Aileen","Anthony"]
name.insert("Aisha", at: 1)
print(name)

//REMOVE
let Anisha = name.remove(at: 1)
print(Anisha)
print(name)
name.removeAll()
print(name)
let Anisha1 = names.removeLast()
print(Anisha1)
print(names)

var myNewArray = names + name
print(myNewArray)

//ARRAYS WITHIN ARRAY
let array1 = [1,2,3]
let array2 = [4,5,6]
let containerArray = [array1 , array2]
let firstArray = containerArray[0]
let firstElement = containerArray[0][0]
print(containerArray)
print(firstArray)
print(firstElement)
*/
//every array is stored as associated
//DICTIONARIES
/*var scores = ["Richard": 500, "Luke": 400 ,"Cheryl" :300]
var myDictionary = [String: Int]()
var myDiction = Dictionary<String,Int>()
scores["Oli"] = 100
if let oldValue = scores.updateValue(1000, forKey:"d"){
    print("Updated old value: \(oldValue)")
}
print(scores)*/

//Array(scores.keys) -> [Richard,luke]
//Array(scores.values) -> [500,400]
//FOR LOOP
let names = ["Andre","Aileen","Anthony"]
for name in names{
    print("Hello \(name)")
}
//enumerated
for(index,letter)in "ABCDEFG".enumerated(){
    print("\(index):\(letter)")
}

let vehicles = ["unicycle":1,"bicycle":2,"tricycle":3,"quadbike":4]
for(vehicleName,wheelCount)in vehicles{
    print("A \(vehicleName) has \(wheelCount) wheels")
}


//WHILE LOOP
var numberOfLives = 3
while numberOfLives > 0{
    print("i still have \(numberOfLives) lives.")
    numberOfLives -= 1
}
for counter in -10...10{
    print(counter)
    if counter == 0{
        break
    }
}
