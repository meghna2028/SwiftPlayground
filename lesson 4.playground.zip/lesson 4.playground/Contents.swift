/*class Person{
    var name: String
    init(name: String) {
        self.name = name
    }
}
var p1 = Person(name:"Meghna")
var p3 = p1
var p2 = Person(name:"Meghna")
print(p1 === p2)//as differnt object
print(p1.name == p2.name)//as same data
print(p1 === p3)//as same object*/

//IF STATEMENT
/*var temp = 100
if(temp > 100){
    print("Boiling water")
}
else{
    print("Not boiling water")
}*/

//DIFFERENCE BETWEEN == AND ===
// === ONLY WHEN OBJECT THERE
/*var a = 10
var b = 10
print(a==b)
class Person{
    var name: String
    init(name: String) {
        self.name = name
    }
}
var p1 = Person(name:"Meghna")
var p3 = p1
var p2 = Person(name:"Meghna")
print(p1===p2)
print(p1.name == p2.name)
print(p1===p3)*/

/*let number = 1000
let isSmallNumber = number < 10
print(isSmallNumber)
var isSnowing: Bool = true
if !isSnowing{
    print("not snowing")
}*/

//SWITCH CASE
/*var value = 3
switch value {
   case 1: print("one")
    fallthrough //takes next case in consideration
 case 3: print("three")
case 2: print("two")
   default: print("other")
}*/

/*let numberOfWheels = 2
switch numberOfWheels {
case 0:
    print("Missing something?")
case 1:
    print("Unicycle")
case 2:
    print("Bicycle")
case 3:
    print("Tricycle")
case 4:
    print("Quadcycle")
default:
    print("That's a lot of wheels!")
}*/

//RANGE
/*var distance = 9
switch distance {
case 0...9:
    print("Getting close")
case 10...99:
    print("Near")
case 100...999:
    print("Getting far")
default:
    print("Not close")
}*/


//EXAMPLE
/*let temperature = 70
switch temperature{
case 65...75:
    print("It's a nice day")
case ...64:
    print("It's too cold")
default:
    print("It's too hot")
}*/

//TERNARY OPERATOR
//variable = condition ? true_value : false_value
var largest:Int
let a = 15
let b = 4
largest = a>b ? a:b
print(largest)
