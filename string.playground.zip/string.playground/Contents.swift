/*var string1 = "Hello"
var string2 = string1 //value assign
//strings are struct type*/

/*let joke = """
Q: This is a question
A: This is answer
"""
print(joke)

let string1 = "Hello"
var string2 = "Hello"
string1 == string2//string is struct which is value type

var string3 = "Hello"
string3 = "hello"//mutable as value can be change
print(string3)*/

/*let greeting = "hello \r world"// /r return to new line "cursor position in beginning of line" /n "cursor position end of new line"


var s1 = "abc\r"
var s2 = "def\n"
var s3 = "ghi"
print(s1)
print(s2)
print(s3)*/

/*var myString = "Hello"
if myString.isEmpty {
    print("The string is empty")
}//isEmpty not a method as no ()  it is a property

//Concatenation
let string1 = "Hello"
let string2 = ", World !"
var result = string1 + string2
print(result)
result += "Hello !"*/

//Interpolation
/*let name = "Sophie"
let age = 30
print("\(name) is \(age) years old")
//interpolation calculate value in between , extrapolation is forcast after it

var s = name + " is " + "\(age)" + " years old"
var a = name + " is " + String(age) + " years old "*/

//Expressions
/*let a = 4
let b = 5
print("If a is \(a) and b is \(b), then a+b is \(a+b)")


//equality
let name = "Jimmy Borghs"
if name.lowercased() == "jiMMy BoRghs".uppercased(){
    print("the two names are same")
}// methods as ()*/

//hasPrefix(),hasSuffix() check if suffix or prefix is there , so bool return used as string.hasPrefix("hello") , is case sensitive

//string.contains()
//checking length
/*let name = "Ryan Notch"//space is counted
let count = name.count
let newPassword = "123456789"
if newPassword.count >= 8 {
    print("password is short")
}*/

//make character compulsory to type annotated let a:Character = "r"
// cannt use let a = 'r'


/*let someCharacter: Character = "e"
switch someCharacter {
    case "a","e","i","o","u":
    print("\(someCharacter) is a vowel")
default:
    print("\(someCharacter) is not a vowel")
}

//Unicode support is there as in all scripts all emoji can be used

let fish = "🐟"
let a = "résumé"
*/
