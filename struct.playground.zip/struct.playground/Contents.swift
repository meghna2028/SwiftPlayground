/*struct Person {
    var name: String = "Anonymous" //need type annotation
    func sayHello(){
        print("Hello , \(name)")
    }
}
var person = Person(name: "John")//parameterized
print(person.name)
person.name = "Jane"
print(person.name)
//person = Person()//default
//print(person.name)
print(person.sayHello())

let string1 = String("aaa")
print(string1)
let string2 = "bbb"

let integer1 = 0
print(integer1)

let boolean = Bool()
print(boolean)

struct bankAccount {
    var name: String
    var balance: Int
}
struct Temperature{
    var celsius : Double
    init(celsius : Double){
        self.celsius = celsius
    }
    init(fahrenheit : Double){
        celsius = (fahrenheit - 32) / 1.8
    }
}
struct Size {
    var width : Double
    var height : Double
func area() -> Double{
    width * height
}
}
var someSize = Size(width: 10, height: 10)
let area = someSize.area()
struct Odometer{
    var reading : Int
    
}
*/

/*struct Temperature{
    var celsius : Double
    var fahrenheit : Double
    var kelvin : Double
    init(celsius : Double){//custom initializer
        self.celsius = celsius
        fahrenheit = celsius * 9/5 + 32
        kelvin = celsius + 273.15
    }
    init(fahrenheit: Double){
    self.fahrenheit = fahrenheit
    celsius = (fahrenheit - 32) / 1.8
    kelvin = celsius + 27
}*/

//COMPUTED PROPERTIES
/*struct Temperature{
    var celsius : Double//stored property
    var fahrenheit : Double{
        celsius * 1.8 + 32//computed property should be var
    }
    var kelvin : Double{
        celsius + 273.15
    }
}
let currentTemperature = Temperature(celsius: 0.0)
print(currentTemperature.kelvin)

//Property observers
struct StepCounter {
    var totalSteps: Int = 0{
    willSet{ //always newvalue
        print("About to set totalSteps to \(newValue)")
    }
    didSet{//old value carry
        if totalSteps > oldValue{
            print("Added \(totalSteps - oldValue) steps")
        }
    }
}
}
var stepCounter = StepCounter()
stepCounter.totalSteps = 40
stepCounter.totalSteps = 100*/

//Type properties and methods
/*struct Temperature{
    static let boilingPoint: Double = 100.0
    static func convertedFromFahrenheit(_ temperatureInFahrenheit : Double) -> Double{
        (((temperatureInFahrenheit - 32)*5)/9)
    }
}
let boilingPoint = Temperature.boilingPoint
let convertedFromFahrenheit = Temperature.convertedFromFahrenheit(99)
//if a struct is copied n struct will not change even if value is changed
struct Size {
    var width : Double
    var height : Double
}
var someSize = Size(width: 20.0, height: 20.0)
var anotherSize = someSize
someSize.width = 40.0
print(someSize.width)
print(anotherSize.width)*/


