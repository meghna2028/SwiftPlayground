import Foundation

let firstName = "MeGhna"
let lastName = "MukherJee"
let username = "Meghna_Mukherjee"
let password = "Swift@123"
let email = "meghna.mukherjee@mitwpu.edu.in"

let formattedFirstName = firstName.capitalized
let formattedLastName = lastName.capitalized

print("Welcome, \(formattedFirstName) \(formattedLastName)!")

let firstThreeLetters = String(firstName.prefix(3)).lowercased()

if username.lowercased().hasPrefix(firstThreeLetters) && username.contains("_") {
    print("Username is valid.")
} else {
    print("Username is invalid.")
}

if password.count >= 8 {
    print("Password has at least 8 characters.")
} else {
    print("Password must contain at least 8 characters.")
}

if password.contains("@") {
    print("Password contains '@' symbol.")
} else {
    print("Password must contain '@' symbol.")
}

if email.contains("@") && email.hasSuffix(".edu.in") {
    print("Educational email verified.")
} else {
    print("Invalid educational email address.")
}

let firstChar = password.first!

switch firstChar {
case "a", "A", "e", "E", "i", "I", "o", "O", "u", "U":
    print("Password starts with a vowel.")
default:
    print("Password starts with a consonant, number, or symbol.")
}

if firstName.lowercased() == lastName.lowercased() {
    print("First name and last name are the same.")
} else {
    print("First name and last name are different.")
}

var summary = ""

if summary.isEmpty {
    summary = "Registration Successful"
}

summary = summary + " - Welcome to the iOS Development Centre!"

print(summary)
